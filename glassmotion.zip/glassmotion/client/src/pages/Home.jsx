import { motion } from 'framer-motion'
import ThreeScene from '../components/ThreeScene'
import WeatherWidget from '../components/WeatherWidget'
import NewsWidget from '../components/NewsWidget'
import QuoteWidget from '../components/QuoteWidget'
import GlassCard from '../components/GlassCard'

export default function Home(){
  return (
    <div className="space-y-10">
      <section className="text-center space-y-6">
        <motion.h1 initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} transition={{duration:0.6}} className="text-4xl md:text-6xl font-extrabold">
          Glassmorphism • Motion • API • 3D
        </motion.h1>
        <p className="opacity-80 max-w-2xl mx-auto">Современный демо‑сайт с плавными анимациями, темной/светлой темой и динамическими виджетами. Внизу — стеклянный тор из Three.js.</p>
        <ThreeScene />
      </section>

      <section className="grid md:grid-cols-3 gap-6">
        <WeatherWidget />
        <NewsWidget />
        <QuoteWidget />
      </section>

      <section>
        <GlassCard>
          <h3 className="text-lg font-semibold mb-2">Почему это круто?</h3>
          <ul className="list-disc pl-6 space-y-1 opacity-90">
            <li>Доступные публичные API без ключей</li>
            <li>Виджет 3D без тяжелых обвязок</li>
            <li>Анимации на Framer Motion</li>
            <li>Glass UI на Tailwind + SCSS</li>
          </ul>
        </GlassCard>
      </section>
    </div>
  )
}
